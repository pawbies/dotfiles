---@meta

---@source UnityEngine.CoreModule.dll
---@class UnityEngine.Internal.DefaultValueAttribute: System.Attribute
---@source UnityEngine.CoreModule.dll
---@field Value object
---@source UnityEngine.CoreModule.dll
CS.UnityEngine.Internal.DefaultValueAttribute = {}

---@source UnityEngine.CoreModule.dll
---@param obj object
---@return Boolean
function CS.UnityEngine.Internal.DefaultValueAttribute.Equals(obj) end

---@source UnityEngine.CoreModule.dll
---@return Int32
function CS.UnityEngine.Internal.DefaultValueAttribute.GetHashCode() end


---@source UnityEngine.CoreModule.dll
---@class UnityEngine.Internal.ExcludeFromDocsAttribute: System.Attribute
---@source UnityEngine.CoreModule.dll
CS.UnityEngine.Internal.ExcludeFromDocsAttribute = {}
