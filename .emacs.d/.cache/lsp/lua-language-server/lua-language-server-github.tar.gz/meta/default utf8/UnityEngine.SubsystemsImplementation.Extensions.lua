---@meta

---@source UnityEngine.SubsystemsModule.dll
---@class UnityEngine.SubsystemsImplementation.Extensions.SubsystemDescriptorExtensions: object
---@source UnityEngine.SubsystemsModule.dll
CS.UnityEngine.SubsystemsImplementation.Extensions.SubsystemDescriptorExtensions = {}

---@source UnityEngine.SubsystemsModule.dll
---@return SubsystemProxy
function CS.UnityEngine.SubsystemsImplementation.Extensions.SubsystemDescriptorExtensions.CreateProxy() end


---@source UnityEngine.SubsystemsModule.dll
---@class UnityEngine.SubsystemsImplementation.Extensions.SubsystemExtensions: object
---@source UnityEngine.SubsystemsModule.dll
CS.UnityEngine.SubsystemsImplementation.Extensions.SubsystemExtensions = {}

---@source UnityEngine.SubsystemsModule.dll
---@return TProvider
function CS.UnityEngine.SubsystemsImplementation.Extensions.SubsystemExtensions.GetProvider() end
