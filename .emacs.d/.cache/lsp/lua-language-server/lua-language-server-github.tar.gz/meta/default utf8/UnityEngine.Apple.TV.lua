---@meta

---@source UnityEngine.CoreModule.dll
---@class UnityEngine.Apple.TV.Remote: object
---@source UnityEngine.CoreModule.dll
---@field allowExitToHome bool
---@source UnityEngine.CoreModule.dll
---@field allowRemoteRotation bool
---@source UnityEngine.CoreModule.dll
---@field reportAbsoluteDpadValues bool
---@source UnityEngine.CoreModule.dll
---@field touchesEnabled bool
---@source UnityEngine.CoreModule.dll
CS.UnityEngine.Apple.TV.Remote = {}
