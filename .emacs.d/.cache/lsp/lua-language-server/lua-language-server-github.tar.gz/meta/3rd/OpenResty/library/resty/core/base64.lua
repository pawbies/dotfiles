---@meta
local resty_core_base64 = {}
resty_core_base64.version = require("resty.core.base").version
return resty_core_base64
