---@meta
local resty_core_shdict = {}
resty_core_shdict.version = require("resty.core.base").version
return resty_core_shdict
