---@meta
local resty_sha = {}
resty_sha._VERSION = require("resty.string")._VERSION
return resty_sha
